# Distributed Storage Deployment

This repository contains YAML manifests and a CI/CD workflow for deploying Kubernetes infrastructure including MetalLB, Prometheus/Grafana, and Rook-Ceph using GitHub Actions.
